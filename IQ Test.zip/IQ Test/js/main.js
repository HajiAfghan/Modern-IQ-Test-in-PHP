// Mobile navigation toggle
document.querySelector('.hamburger').addEventListener('click', function() {
    document.querySelector('.nav-links').classList.toggle('active');
});

// Close mobile menu when clicking on a link
document.querySelectorAll('.nav-links a').forEach(link => {
    link.addEventListener('click', () => {
        document.querySelector('.nav-links').classList.remove('active');
    });
});

// Test timer functionality
if (document.getElementById('test-timer')) {
    let timeLeft = 1800; // 30 minutes in seconds
    const timer = document.getElementById('test-timer');
    
    const updateTimer = () => {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timer.textContent = `${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
        
        if (timeLeft <= 0) {
            clearInterval(timerInterval);
            document.getElementById('iq-test-form').submit();
        } else {
            timeLeft--;
        }
    };
    
    const timerInterval = setInterval(updateTimer, 1000);
    updateTimer();
}

// Form validation
document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', function(e) {
        let isValid = true;
        
        // Check required fields
        this.querySelectorAll('[required]').forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('error');
            } else {
                field.classList.remove('error');
            }
        });
        
        // Password match validation for registration
        if (this.id === 'register-form' && this.querySelector('#password').value !== this.querySelector('#confirm_password').value) {
            isValid = false;
            alert('Passwords do not match!');
        }
        
        if (!isValid) {
            e.preventDefault();
        }
    });
});

// Smooth scrolling for anchor links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});