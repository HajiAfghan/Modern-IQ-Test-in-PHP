<?php 
include 'includes/config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get result data
if (isset($_GET['id'])) {
    $result_id = intval($_GET['id']);
    
    if (!isset($_SESSION['test_results'][$result_id])) {
        header('Location: dashboard.php');
        exit();
    }
    
    $test_result = $_SESSION['test_results'][$result_id];
    $iq_score = $test_result['score'];
    $percentile = $test_result['percentile'];
    $user_answers = $test_result['answers'];
} else {
    header('Location: dashboard.php');
    exit();
}

// Determine IQ classification
if ($iq_score >= 140) {
    $classification = 'جینوس یا نږدې جینوس';
} elseif ($iq_score >= 120) {
    $classification = 'ډیر لوړ هوښیارتیا';
} elseif ($iq_score >= 110) {
    $classification = 'لوړ هوښیارتیا';
} elseif ($iq_score >= 90) {
    $classification = 'نورمال یا منځنۍ هوښیارتیا';
} elseif ($iq_score >= 80) {
    $classification = 'کمزوري';
} elseif ($iq_score >= 70) {
    $classification = 'پوله ایزي کمزوري';
} else {
    $classification = 'ښکاره کمزوري';
}
?>

<?php include 'includes/header.php'; ?>

<div class="container">
    <div class="result-container">
        <div class="card">
            <h2>ستاسو د آی کیو ازموینې پایلې</h2>
            
            <div class="result-score"><?php echo $iq_score; ?></div>
            <div class="result-percentile">سلنه: <?php echo $percentile; ?>%</div>
            
            <div class="result-description">
                <p>ستاسو د آی کیو نمره <?php echo $iq_score; ?> ده چې د <strong><?php echo $classification; ?></strong> په توګه طبقه بندي شوې.</p>
                <p>دا پدې معنی ده چې تاسو د <?php echo $percentile; ?>٪ خلکو څخه ښه ګټلی یاست چې دا ازموینه کړې.</p>
            </div>
            
            <h3>د هرې پوښتنې پایلې</h3>
            <div class="question-results">
                <?php foreach ($user_answers as $q_id => $answer): ?>
                <div class="question-result <?php echo $answer['is_correct'] ? 'correct' : 'incorrect'; ?>">
                    <div class="question-text">
                        <strong>پوښتنه:</strong> <?php echo htmlspecialchars($answer['question_text']); ?>
                    </div>
                    <div class="correct-answer">
                        <strong>سم ځواب:</strong> <?php echo strtoupper($answer['correct_answer']); ?>
                    </div>
                    <div class="user-answer">
                        <strong>ستاسو ځواب:</strong> 
                        <?php echo $answer['user_answer'] ? strtoupper($answer['user_answer']) : 'هیڅ ځواب نه دی ورکړ شوی'; ?>
                    </div>
                    <div class="result-status">
                        <?php if ($answer['is_correct']): ?>
                            <span class="correct-mark">✓ سم</span>
                        <?php else: ?>
                            <span class="incorrect-mark">✖ ناسم</span>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <!-- Add this after the question-results div -->
<div class="question-results-table">
    <table>
        <thead>
            <tr>
                <th>پوښتنه</th>
                <th>ستاسو ځواب</th>
                <th>سم ځواب</th>
                <th>حالت</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($user_answers as $q_id => $answer): ?>
            <tr class="<?php echo $answer['is_correct'] ? 'correct-row' : 'incorrect-row'; ?>">
                <td><?php echo htmlspecialchars($answer['question_text']); ?></td>
                <td><?php echo $answer['user_answer'] ? strtoupper($answer['user_answer']) : 'هیڅ'; ?></td>
                <td><?php echo strtoupper($answer['correct_answer']); ?></td>
                <td>
                    <?php if ($answer['is_correct']): ?>
                        <span class="correct-mark">✓ سم</span>
                    <?php else: ?>
                        <span class="incorrect-mark">✖ ناسم</span>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
            <a href="dashboard.php" class="btn">بیرته ډشبورډ ته</a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>