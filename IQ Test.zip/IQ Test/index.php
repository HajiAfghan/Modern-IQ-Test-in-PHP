<?php include 'includes/config.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="hero">
    <div class="container">
        <h1>Test Your Intelligence</h1>
        <p>Take our scientifically validated IQ test and discover your cognitive strengths</p>
        <?php if(isset($_SESSION['user_id'])): ?>
            <a href="test.php" class="btn">Take the Test</a>
        <?php else: ?>
            <a href="register.php" class="btn">Get Started</a>
            <a href="login.php" class="btn btn-secondary">Login</a>
        <?php endif; ?>
    </div>
</div>

<div class="container">
    <div class="card">
        <h2>About Our IQ Test</h2>
        <p>Our IQ test is designed by psychologists and cognitive scientists to provide an accurate measure of your intelligence. The test includes questions that assess various cognitive abilities including logical reasoning, pattern recognition, and problem-solving skills.</p>
        <p>The test takes approximately 30 minutes to complete and consists of 40 multiple-choice questions. Your results will include an IQ score, percentile ranking, and detailed analysis of your cognitive strengths.</p>
    </div>

    <div class="card">
        <h2>Why Take Our Test?</h2>
        <div class="features">
            <div class="feature">
                <i class="fas fa-chart-line"></i>
                <h3>Accurate Results</h3>
                <p>Our test is scientifically validated to provide reliable IQ scores.</p>
            </div>
            <div class="feature">
                <i class="fas fa-lock"></i>
                <h3>Secure & Private</h3>
                <p>Your test results are confidential and stored securely.</p>
            </div>
            <div class="feature">
                <i class="fas fa-file-alt"></i>
                <h3>Detailed Report</h3>
                <p>Receive a comprehensive analysis of your cognitive abilities.</p>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>