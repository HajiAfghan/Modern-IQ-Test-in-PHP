<?php 
include 'includes/config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get all questions from database
    $stmt = $conn->prepare("SELECT id, question_text, correct_answer FROM questions ORDER BY difficulty_level ASC LIMIT 40");
    $stmt->execute();
    $questions = $stmt->get_result();
    $stmt->close();
    
    $score = 0;
    $total_questions = $questions->num_rows;
    $user_answers = [];
    
    // Check if there are any questions
    if ($total_questions === 0) {
        $_SESSION['error'] = 'هیڅ پوښتنې په ډیټابیس کې نشته!';
        header('Location: test.php');
        exit();
    }
    
    // Calculate score and store user answers
    while($question = $questions->fetch_assoc()) {
        $question_id = $question['id'];
        $user_answer = isset($_POST['q' . $question_id]) ? $_POST['q' . $question_id] : null;
        
        $user_answers[$question_id] = [
            'question_text' => $question['question_text'],
            'correct_answer' => $question['correct_answer'],
            'user_answer' => $user_answer,
            'is_correct' => ($user_answer == $question['correct_answer'])
        ];
        
        if ($user_answers[$question_id]['is_correct']) {
            $score++;
        }
    }
    
    // Calculate IQ score and percentile
    $iq_score = round(100 + ($score - $total_questions/2) * 2);
    $percentile = ($total_questions > 0) ? round(($score / $total_questions) * 100) : 0;
    $percentile = max(0, min(100, $percentile));
    
    // Save results to database
    $stmt = $conn->prepare("INSERT INTO test_results (user_id, score, percentile) VALUES (?, ?, ?)");
    $stmt->bind_param("iii", $_SESSION['user_id'], $iq_score, $percentile);
    
    if ($stmt->execute()) {
        $result_id = $stmt->insert_id;
        $stmt->close();
        
        // Store user answers in session for display
        $_SESSION['test_results'][$result_id] = [
            'score' => $iq_score,
            'percentile' => $percentile,
            'answers' => $user_answers
        ];
        
        // Redirect to results page
        header("Location: result.php?id=$result_id");
        exit();
    } else {
        $_SESSION['error'] = 'د ازموینې پایلې خوندي کولو کې ستونزه راغله!';
        header('Location: test.php');
        exit();
    }
} else {
    header('Location: test.php');
    exit();
}
?>