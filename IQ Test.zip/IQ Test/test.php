<?php 
include 'includes/config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get questions from database
$stmt = $conn->prepare("SELECT * FROM questions ORDER BY difficulty_level ASC LIMIT 40");
$stmt->execute();
$questions = $stmt->get_result();
$stmt->close();
?>

<?php include 'includes/header.php'; ?>

<div class="container">
    <div class="test-container">
        <div class="card">
            <h2>IQ Test</h2>
            <p>This test consists of 40 questions with a time limit of 30 minutes. Answer all questions to the best of your ability.</p>
            <p>Time remaining: <span id="test-timer">30:00</span></p>
            
            <form id="iq-test-form" action="process_test.php" method="POST">
                <?php 
                $question_num = 1;
                while($question = $questions->fetch_assoc()): 
                ?>
                    <div class="question">
                        <div class="question-text"><?php echo $question_num . '. ' . htmlspecialchars($question['question_text']); ?></div>
                        <div class="options">
                            <label class="option">
                                <input type="radio" name="q<?php echo $question['id']; ?>" value="a" required>
                                <?php echo htmlspecialchars($question['option_a']); ?>
                            </label>
                            <label class="option">
                                <input type="radio" name="q<?php echo $question['id']; ?>" value="b">
                                <?php echo htmlspecialchars($question['option_b']); ?>
                            </label>
                            <label class="option">
                                <input type="radio" name="q<?php echo $question['id']; ?>" value="c">
                                <?php echo htmlspecialchars($question['option_c']); ?>
                            </label>
                            <label class="option">
                                <input type="radio" name="q<?php echo $question['id']; ?>" value="d">
                                <?php echo htmlspecialchars($question['option_d']); ?>
                            </label>
                        </div>
                    </div>
                <?php 
                $question_num++;
                endwhile; 
                ?>
                
                <button type="submit" class="btn">Submit Test</button>
            </form>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>