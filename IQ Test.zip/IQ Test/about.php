<?php include 'includes/config.php'; ?>
<?php include 'includes/header.php'; ?>

<div class="container">
    <div class="card">
        <h2>About Our IQ Test</h2>
        <p>Our IQ test is designed by a team of psychologists and cognitive scientists to provide an accurate measure of general intelligence. The test follows established psychometric principles and has been validated through extensive research.</p>
        
        <h3>Test Methodology</h3>
        <p>The test consists of 40 multiple-choice questions that assess various cognitive abilities including:</p>
        <ul>
            <li>Logical reasoning</li>
            <li>Pattern recognition</li>
            <li>Verbal comprehension</li>
            <li>Spatial visualization</li>
            <li>Mathematical ability</li>
        </ul>
        
        <h3>Scoring System</h3>
        <p>IQ scores are calculated based on your performance relative to a normative sample. The average score is set at 100, with a standard deviation of 15. This means:</p>
        <ul>
            <li>68% of people score between 85 and 115</li>
            <li>95% of people score between 70 and 130</li>
            <li>99.7% of people score between 55 and 145</li>
        </ul>
        
        <h3>Privacy and Data Security</h3>
        <p>We take your privacy seriously. All test results are stored securely and anonymously. We will never share your personal information or test results without your explicit consent.</p>
    </div>
</div>

<?php include 'includes/footer.php'; ?>