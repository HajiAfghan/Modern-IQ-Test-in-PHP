<?php 
include 'includes/config.php';

// Redirect if not logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

// Get user's test results
$stmt = $conn->prepare("SELECT * FROM test_results WHERE user_id = ? ORDER BY test_date DESC");
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$results = $stmt->get_result();
$stmt->close();
?>

<?php include 'includes/header.php'; ?>

<div class="container">
    <div class="card">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['username']); ?></h2>
        
        <div class="dashboard-actions">
            <a href="test.php" class="btn">Take New Test</a>
            <a href="logout.php" class="btn btn-secondary">Logout</a>
        </div>
    </div>
    
    <div class="card">
        <h2>Your Test Results</h2>
        
        <?php if($results->num_rows > 0): ?>
            <div class="results-table">
                <table>
                    <thead>
                        <tr>
                            <th>Test Date</th>
                            <th>IQ Score</th>
                            <th>Percentile</th>
                            <th>Details</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while($row = $results->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo date('M j, Y g:i a', strtotime($row['test_date'])); ?></td>
                                <td><?php echo $row['score']; ?></td>
                                <td><?php echo $row['percentile']; ?>%</td>
                                <td><a href="result.php?id=<?php echo $row['id']; ?>" class="btn">View</a></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <p>You haven't taken any tests yet. <a href="test.php">Take your first test now!</a></p>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>