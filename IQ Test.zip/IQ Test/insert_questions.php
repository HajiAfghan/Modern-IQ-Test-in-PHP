<?php
include 'includes/config.php';

$questions = [
    // Pattern Recognition (10 questions)
    [
        'question_text' => 'راتلونکی شکل کوم دی؟ ▷, ◇, ▷, ◇, ▷, ?',
        'option_a' => '▷',
        'option_b' => '◇',
        'option_c' => '○',
        'option_d' => '□',
        'correct_answer' => 'b',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'لاندې ترتیب بشپړ کړئ: ۲, ۴, ۸, ۱۶, ?',
        'option_a' => '۲۴',
        'option_b' => '۳۲',
        'option_c' => '۶۴',
        'option_d' => '۱۲۸',
        'correct_answer' => 'b',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'کوم شکل د نورو سره توپیر لري؟',
        'option_a' => 'مربع',
        'option_b' => 'مستطیل',
        'option_c' => 'دایره',
        'option_d' => 'مثلث',
        'correct_answer' => 'c',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'راتلونکی عدد کوم دی؟ ۵, ۱۰, ۱۵, ۲۰, ?',
        'option_a' => '۲۲',
        'option_b' => '۲۵',
        'option_c' => '۳۰',
        'option_d' => '۳۵',
        'correct_answer' => 'b',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'د شکلونو ترتیب: ستوری, مربع, ستوری, مربع, ستوری, ?',
        'option_a' => 'ستوری',
        'option_b' => 'مربع',
        'option_c' => 'مثلث',
        'option_d' => 'دایره',
        'correct_answer' => 'b',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'کومه رنګ دلته مختلفه ده؟',
        'option_a' => 'سپین',
        'option_b' => 'تور',
        'option_c' => 'شین',
        'option_d' => 'سور',
        'correct_answer' => 'a',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'لاندې ترتیب بشپړ کړئ: A, C, E, G, ?',
        'option_a' => 'H',
        'option_b' => 'I',
        'option_c' => 'J',
        'option_d' => 'K',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'د ۱، ۱، ۲، ۳، ۵، ۸، ? راتلونکی عدد کوم دی؟',
        'option_a' => '۱۰',
        'option_b' => '۱۱',
        'option_c' => '۱۲',
        'option_d' => '۱۳',
        'correct_answer' => 'd',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'کوم شکل د نورو سره توپیر لري؟',
        'option_a' => 'لاله',
        'option_b' => 'ګل',
        'option_c' => 'وړه',
        'option_d' => 'وږه',
        'correct_answer' => 'd',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'راتلونکی شکل کوم دی؟ △, □, ○, △, □, ○, △, ?',
        'option_a' => '△',
        'option_b' => '□',
        'option_c' => '○',
        'option_d' => '☆',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],

    // Mathematics (10 questions)
    [
        'question_text' => 'که ۵ کارګر یوه دنده په ۱۰ ورځو کې پای ته رسولی شي، نو ۱۰ کارګر به په څو ورځو کې پای ته رسوي؟',
        'option_a' => '۲',
        'option_b' => '۵',
        'option_c' => '۱۰',
        'option_d' => '۲۰',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'د ۱۲ او ۱۸ ترمنځ لوی عمومی تقسیم کوونکی څومره دی؟',
        'option_a' => '۳',
        'option_b' => '۶',
        'option_c' => '۹',
        'option_d' => '۱۲',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'د ۳، ۵، او ۷ ترمنځ لږترلږه عمومي ضربېدونکی څومره دی؟',
        'option_a' => '۳۵',
        'option_b' => '۷۰',
        'option_c' => '۱۰۵',
        'option_d' => '۲۱۰',
        'correct_answer' => 'c',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'که یو کتاب ۲۵۰ افغانۍ قیمت ولري، نو ۴ کتابونه څو افغانۍ قیمت لري؟',
        'option_a' => '۵۰۰',
        'option_b' => '۷۵۰',
        'option_c' => '۱۰۰۰',
        'option_d' => '۱۲۵۰',
        'correct_answer' => 'c',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'د ۱۰۰٪ ۲۵٪ څومره کېږي؟',
        'option_a' => '۲۰',
        'option_b' => '۲۵',
        'option_c' => '۵۰',
        'option_d' => '۷۵',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که ۲x + ۵ = ۱۵ وي، نو x څومره دی؟',
        'option_a' => '۵',
        'option_b' => '۷',
        'option_c' => '۱۰',
        'option_d' => '۱۲',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'د ۱ کیلومتر څومره متره دي؟',
        'option_a' => '۱۰',
        'option_b' => '۱۰۰',
        'option_c' => '۱۰۰۰',
        'option_d' => '۱۰۰۰۰',
        'correct_answer' => 'c',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'د ۹ مربع څومره دی؟',
        'option_a' => '۱۸',
        'option_b' => '۲۷',
        'option_c' => '۶۴',
        'option_d' => '۸۱',
        'correct_answer' => 'd',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'د ۸ او ۱۲ ترمنځ اوسط څومره دی؟',
        'option_a' => '۸',
        'option_b' => '۱۰',
        'option_c' => '۱۲',
        'option_d' => '۲۰',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که ۱۰۰ افغانۍ ۵ سکې وي، نو د هرې سکې قیمت څومره دی؟',
        'option_a' => '۵',
        'option_b' => '۱۰',
        'option_c' => '۲۰',
        'option_d' => '۵۰',
        'correct_answer' => 'c',
        'difficulty_level' => 1
    ],

    // Verbal Reasoning (10 questions)
    [
        'question_text' => 'که "سپين" د "تور" په څير وي، نو "ورځ" د چا په څير وي؟',
        'option_a' => 'شپه',
        'option_b' => 'رڼا',
        'option_c' => 'لمر',
        'option_d' => 'مياشت',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'کومه کلمه د نورو سره توپیر لري؟',
        'option_a' => 'لیونی',
        'option_b' => 'عاقل',
        'option_c' => 'هوښیار',
        'option_d' => 'پوه',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که "مرغۍ" د "الوتل" سره اړیکه لري، نو "کب" د چا سره اړیکه لري؟',
        'option_a' => 'چلیدل',
        'option_b' => 'الوتل',
        'option_c' => 'لاندې',
        'option_d' => 'لنګیدل',
        'correct_answer' => 'd',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'کومه کلمه د "لوی" معکوس معنی لري؟',
        'option_a' => 'نوی',
        'option_b' => 'کوچنی',
        'option_c' => 'نږدې',
        'option_d' => 'لرې',
        'correct_answer' => 'b',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'د "کتاب" او "لیکوال" ترمنځ اړیکه د "فیلم" او چا سره ورته ده؟',
        'option_a' => 'لوبغاړی',
        'option_b' => 'کیمره',
        'option_c' => 'سکرین',
        'option_d' => 'ډایرکټر',
        'correct_answer' => 'd',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'کومه کلمه د نورو سره توپیر لري؟',
        'option_a' => 'کابل',
        'option_b' => 'مزارشریف',
        'option_c' => 'کندهار',
        'option_d' => 'دريا',
        'correct_answer' => 'd',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'د "سړک" او "موټر" ترمنځ اړیکه د "اوبه" او چا سره ورته ده؟',
        'option_a' => 'بېړۍ',
        'option_b' => 'اوبل',
        'option_c' => 'څښاک',
        'option_d' => 'چینې',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'کومه کلمه د نورو سره توپیر لري؟',
        'option_a' => 'پسرلی',
        'option_b' => 'ډیګر',
        'option_c' => 'منی',
        'option_d' => 'ژمی',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که "لیک" د "قلم" سره اړیکه لري، نو "غږ" د چا سره اړیکه لري؟',
        'option_a' => 'غږیز',
        'option_b' => 'غږول',
        'option_c' => 'غږیدل',
        'option_d' => 'غږونه',
        'correct_answer' => 'b',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'کومه کلمه د "ګرم" معکوس معنی لري؟',
        'option_a' => 'سوړ',
        'option_b' => 'تود',
        'option_c' => 'نرم',
        'option_d' => 'کلک',
        'correct_answer' => 'a',
        'difficulty_level' => 1
    ],

    // Logical Reasoning (10 questions)
    [
        'question_text' => 'که نن سبا وړاندې ورځ ده، نو هغه ورځ چې سبا به وړاندې دوه ورځې ده، هغه کومه ده؟',
        'option_a' => 'نن',
        'option_b' => 'سبا',
        'option_c' => 'پرون',
        'option_d' => 'تېره ورځ',
        'correct_answer' => 'c',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'که A د B پلار وي، B د C پلار وي، نو A د C څه شی دی؟',
        'option_a' => 'پلار',
        'option_b' => 'نیکه',
        'option_c' => 'تره',
        'option_d' => 'ورور',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که موټر د موټرسایکل څلور چرخه لري، نو موټرسایکل څو چرخه لري؟',
        'option_a' => '۱',
        'option_b' => '۲',
        'option_c' => '۳',
        'option_d' => '۴',
        'correct_answer' => 'b',
        'difficulty_level' => 1
    ],
    [
        'question_text' => 'که دوه ساعتونه وروسته، ساعت ۷:۰۰ وښيي، نو اوس څو بجې دي؟',
        'option_a' => '۵:۰۰',
        'option_b' => '۷:۰۰',
        'option_c' => '۹:۰۰',
        'option_d' => '۱۱:۰۰',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که د ۵ ورځو وروسته دوه ورځې وړاندې د جمعې ورځ وي، نو نن کومه ورځ ده؟',
        'option_a' => 'اتوار',
        'option_b' => 'څلرنۍ',
        'option_c' => 'پنځنۍ',
        'option_d' => 'جمعه',
        'correct_answer' => 'c',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'که زه د خپلې خور د خور یم، نو زه د هغې څه یم؟',
        'option_a' => 'خور',
        'option_b' => 'ورور',
        'option_c' => 'ماما',
        'option_d' => 'ترور',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'د ۵ کسانو لپاره د ۵ ډوډۍ خوړل ۵ دقیقې وخت نیسي، نو د ۱۰ کسانو لپاره ۱۰ ډوډۍ خوړل څو دقیقې وخت نیسي؟',
        'option_a' => '۵',
        'option_b' => '۱۰',
        'option_c' => '۲۰',
        'option_d' => '۵۰',
        'correct_answer' => 'a',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'که یو سړی خپلې ښځې ته وايي "ستا مور زما د مور خور ده"، نو هغه د ښځې سره څه اړیکه لري؟',
        'option_a' => 'ورور',
        'option_b' => 'ماما',
        'option_c' => 'ترور',
        'option_d' => 'نیکه',
        'correct_answer' => 'b',
        'difficulty_level' => 3
    ],
    [
        'question_text' => 'که دوه کسان د یوه دیوال رنګولو لپاره دوه ساعتونه وخت نیسي، نو یو کس به څو ساعتونه وخت ونیسي؟',
        'option_a' => '۱',
        'option_b' => '۲',
        'option_c' => '۴',
        'option_d' => '۸',
        'correct_answer' => 'b',
        'difficulty_level' => 2
    ],
    [
        'question_text' => 'که د ۵ کچې وروسته ۳ کچې راکښته شو، نو اوس تاسو په کومه کچه یاست؟',
        'option_a' => '۲',
        'option_b' => '۳',
        'option_c' => '۵',
        'option_d' => '۸',
        'correct_answer' => 'a',
        'difficulty_level' => 2
    ]
];

$stmt = $conn->prepare("INSERT INTO questions (question_text, option_a, option_b, option_c, option_d, correct_answer, difficulty_level) VALUES (?, ?, ?, ?, ?, ?, ?)");

foreach ($questions as $q) {
    $stmt->bind_param("ssssssi", $q['question_text'], $q['option_a'], $q['option_b'], $q['option_c'], $q['option_d'], $q['correct_answer'], $q['difficulty_level']);
    $stmt->execute();
}

$stmt->close();
echo "۴۰ پوښتنې په پښتو ژبه په ډاټابيس کې اضافه شوې!";
?>