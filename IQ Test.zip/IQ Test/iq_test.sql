-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Aug 08, 2025 at 02:18 PM
-- Server version: 5.7.34
-- PHP Version: 8.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `iq_test`
--

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `option_a` varchar(255) NOT NULL,
  `option_b` varchar(255) NOT NULL,
  `option_c` varchar(255) NOT NULL,
  `option_d` varchar(255) NOT NULL,
  `correct_answer` char(1) NOT NULL,
  `difficulty_level` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_text`, `option_a`, `option_b`, `option_c`, `option_d`, `correct_answer`, `difficulty_level`) VALUES
(78, 'که زه د خپلې خور د خور یم، نو زه د هغې څه یم؟', 'خور', 'ورور', 'ماما', 'ترور', 'a', 2),
(77, 'که د ۵ ورځو وروسته دوه ورځې وړاندې د جمعې ورځ وي، نو نن کومه ورځ ده؟', 'اتوار', 'څلرنۍ', 'پنځنۍ', 'جمعه', 'c', 3),
(76, 'که دوه ساعتونه وروسته، ساعت ۷:۰۰ وښيي، نو اوس څو بجې دي؟', '۵:۰۰', '۷:۰۰', '۹:۰۰', '۱۱:۰۰', 'a', 2),
(75, 'که موټر د موټرسایکل څلور چرخه لري، نو موټرسایکل څو چرخه لري؟', '۱', '۲', '۳', '۴', 'b', 1),
(74, 'که الف د ب پلار وی او ب د ث مور وی نو ث د الف څه کیږی؟', 'پلار', 'مور', 'خاله', 'میرمن', 'd', 2),
(66, 'کومه کلمه د \"لوی\" معکوس معنی لري؟', 'نوی', 'کوچنی', 'نږدې', 'لرې', 'b', 1),
(65, 'که \"مرغۍ\" د \"الوتل\" سره اړیکه لري، نو \"کب\" د چا سره اړیکه لري؟', 'چلیدل', 'الوتل', 'اوبازی', 'لنګیدل', 'd', 2),
(64, 'کومه کلمه د نورو سره توپیر لري؟', 'لیونی', 'عاقل', 'هوښیار', 'پوه', 'a', 2),
(63, 'که \"سپين\" د \"تور\" په څير وي، نو \"ورځ\" د چا په څير وي؟', 'شپه', 'رڼا', 'لمر', 'مياشت', 'a', 2);

-- --------------------------------------------------------

--
-- Table structure for table `test_results`
--

CREATE TABLE `test_results` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `score` int(11) NOT NULL,
  `percentile` int(11) NOT NULL,
  `test_date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `test_results`
--

INSERT INTO `test_results` (`id`, `user_id`, `score`, `percentile`, `test_date`) VALUES
(1, 1, 98, 0, '2025-08-08 15:38:56'),
(2, 1, 98, 0, '2025-08-08 15:39:30'),
(3, 1, 98, 0, '2025-08-08 15:42:57'),
(4, 2, 114, 68, '2025-08-08 15:57:47'),
(5, 2, 103, 67, '2025-08-08 16:08:03'),
(6, 2, 95, 22, '2025-08-08 16:37:38'),
(7, 2, 99, 44, '2025-08-08 16:38:19');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `created_at`) VALUES
(1, 'Afghan', 'sadiqullah.afghan1998@gmail.com', '$2y$10$2BpdJXi55jAl1gmE2j3G1.hRYGO57NWT.O0JN8GoayzZDMHF2Hz8G', '2025-08-08 15:36:36'),
(2, 'Khan', 'khan@x.com', '$2y$10$EUrGRITwRylrXf52HIACW.UYt9TqtoPz5z86HKw4dTcqVceDj.s8a', '2025-08-08 15:44:40');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_results`
--
ALTER TABLE `test_results`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `test_results`
--
ALTER TABLE `test_results`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
